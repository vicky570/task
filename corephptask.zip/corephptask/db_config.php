<?php
	$dbHost = "localhost";
	$dbDatabase = "task_php";
	$dbPasswrod = "";
	$dbUser = "root";
	$mysqli = new mysqli($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
?>